Requirements: (CLOSED)
AE Upgrade (CC Fishing)
MCM Helper
SkyUI

Requirements: (OPEN)
SKSE
Po3 Papyrus Extender

Note: OPEN PERMS MODULE NEEDS FACEGEN. CK keeps failing to export for me.

CLOSED PERMS
Proving Honor Companions Quest Progression Fix	https://www.nexusmods.com/skyrimspecialedition/mods/66128
Chill Out Aela	https://www.nexusmods.com/skyrimspecialedition/mods/31949
Silence is Golden	https://www.nexusmods.com/skyrimspecialedition/mods/50581
A Good Death - Old Orc's Various Opponents	https://www.nexusmods.com/skyrimspecialedition/mods/15561
Stop being mean to me I saved your daughter.	https://www.nexusmods.com/skyrimspecialedition/mods/66425
Alikr Accusation Happens Only Once	https://www.nexusmods.com/skyrimspecialedition/mods/35830
A Lovely Letter Alternate Routes	https://www.nexusmods.com/skyrimspecialedition/mods/21916
Assorted Tiny Tweaks	https://www.nexusmods.com/skyrimspecialedition/mods/43834
Bounty Preview	https://www.nexusmods.com/skyrimspecialedition/mods/33877
Freed Prisoner Uses Items	https://www.nexusmods.com/skyrimspecialedition/mods/22152
Improved Companions - Questline Tweaks	https://www.nexusmods.com/skyrimspecialedition/mods/22300
Improved College Entry - Questline Tweaks	https://www.nexusmods.com/skyrimspecialedition/mods/22184
Deceive Degaine	https://www.nexusmods.com/skyrimspecialedition/mods/51863
Civil War intro scenes run only once	https://www.nexusmods.com/skyrimspecialedition/mods/22028
Windhelm Segregation - Stay at New Gnisis Cornerclub	https://www.nexusmods.com/skyrimspecialedition/mods/21181
Siddgeir's Rare Gifts and Hearthfire BYOH Quest Compatibility	https://www.nexusmods.com/skyrimspecialedition/mods/26969
Thugs Not Assassins	https://www.nexusmods.com/skyrimspecialedition/mods/34028
EMPEROR - Giant Crab Overhaul	https://www.nexusmods.com/skyrimspecialedition/mods/58612?tab=description
Sven Ballad Dialogue Option Restored - Cut Content Restoration	https://www.nexusmods.com/skyrim/mods/83008
Savos Aren's Regrets Restored - Cut Content Restoration	https://www.nexusmods.com/skyrim/mods/108000
Lights Out. Solitude Lighthouse Fix	https://www.nexusmods.com/skyrimspecialedition/mods/34976
Path to Volkihar--Vampires Can Skip Fort Dawnguard	https://www.nexusmods.com/skyrimspecialedition/mods/25783
Ulfr The Blind - Consistency Fix	https://www.nexusmods.com/skyrimspecialedition/mods/78086
Nilheim - Misc Quest Expansion	https://www.nexusmods.com/skyrimspecialedition/mods/53792
Save the Icerunner - Lights Out Alternate Routes	https://www.nexusmods.com/skyrimspecialedition/mods/34681
Search and Seizure for Good Guys	https://www.nexusmods.com/skyrimspecialedition/mods/36693
Essence Extractor Script SE - Use your own blood for the quest	https://www.nexusmods.com/skyrimspecialedition/mods/49892
Return to the Thalmor Embassy	https://www.nexusmods.com/skyrimspecialedition/mods/50762
Runic Dawnguard - Separated Lost Relic Questline	https://www.nexusmods.com/skyrimspecialedition/mods/63108
Radiant Requirements MCM	https://www.nexusmods.com/skyrimspecialedition/mods/45427
Immersive Dark Brotherhood Kidnapping	https://www.nexusmods.com/skyrimspecialedition/mods/39326
Finding Susanna Alive	https://www.nexusmods.com/skyrimspecialedition/mods/32512
Slower Markarth Assassination	https://www.nexusmods.com/skyrimspecialedition/mods/53084
You Handle Yourself Well - A Tougher Giant Encounter	https://www.nexusmods.com/skyrimspecialedition/mods/60502


OPEN PERMS
Bring Meeko to Lod	https://www.nexusmods.com/skyrimspecialedition/mods/25246
Random Encounter Tweaks SE	https://www.nexusmods.com/skyrimspecialedition/mods/53300
Riverwood Trader Is A Mess	https://www.nexusmods.com/skyrimspecialedition/mods/63631
Sidequests of Skyrim	https://www.nexusmods.com/skyrimspecialedition/mods/54245
Better Wedding Guests	https://www.nexusmods.com/skyrim/mods/100524
Say No To Calcelmo	https://www.nexusmods.com/skyrimspecialedition/mods/69991
The Matriarch	https://www.nexusmods.com/skyrimspecialedition/mods/49019
Scene Tweak - The Book of Love - Calcelmo and Faleen hug	https://www.nexusmods.com/skyrimspecialedition/mods/54976