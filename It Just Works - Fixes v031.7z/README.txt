Requirements:
SKSE
Papyrus Script Extender

Open only:
SkyUI
AE Upgrade (CC Fishing)
ConsoleUtilSSE


CLOSED PERMS:
Modern Brawl Bug Fix	https://www.nexusmods.com/skyrimspecialedition/mods/1473
CritterSpawn Congestion Fix	https://www.nexusmods.com/skyrimspecialedition/mods/67276
Hearthfire Grass Fix	https://www.nexusmods.com/skyrimspecialedition/mods/13461
Dragon Stalking Fix	https://www.nexusmods.com/skyrimspecialedition/mods/14060
Vanilla Script (micro)Optimizations	https://www.nexusmods.com/skyrimspecialedition/mods/54061
Chillwind Depths CTD Fix	https://www.nexusmods.com/skyrimspecialedition/mods/44249
Dawnguard Don't Hunt Cured Vampires	https://www.nexusmods.com/skyrimspecialedition/mods/5471
Trinity Restored Karliah Gate Bug Fix	https://www.nexusmods.com/skyrim/mods/109188
Rude Imperial Soldiers Escort Prisoner fix	https://www.nexusmods.com/skyrimspecialedition/mods/894
HearthFires Display Case Fix SE	https://www.nexusmods.com/skyrimspecialedition/mods/15104
Fast Travel Speed Fix	https://www.nexusmods.com/skyrimspecialedition/mods/1503
Improved Redbelly Mine Mist Fix	https://www.nexusmods.com/skyrimspecialedition/mods/21715
Mfg Fix	https://www.nexusmods.com/skyrimspecialedition/mods/11669
Vanilla Scripting Enhancements	https://www.nexusmods.com/skyrimspecialedition/mods/68139
NPC's Run and Walk at Your Pace	https://www.nexusmods.com/skyrimspecialedition/mods/2482
Skeletons don't breathe SSE	https://www.nexusmods.com/skyrimspecialedition/mods/18542
	

OPEN PERMS
Falkreath Pinewatch Bandit Bridge - dead bandits don't trigger trap	https://www.nexusmods.com/skyrimspecialedition/mods/38477
King Olaf's Fire Festival Not Ending Fix	https://www.nexusmods.com/skyrimspecialedition/mods/65849
Neloth's Experimental Subject Quest (DLC2TTR4a) Fix	https://www.nexusmods.com/skyrimspecialedition/mods/64016
High Gate Ruins Puzzle Reset Fix	https://www.nexusmods.com/skyrimspecialedition/mods/53643
Narrative Gameplay Consistent Dialogue Tweaks	https://www.nexusmods.com/skyrimspecialedition/mods/64667
Raven Rock - Fix Exit on Horseback	https://www.nexusmods.com/skyrimspecialedition/mods/14075
Fish Plaque Fix	https://www.nexusmods.com/skyrimspecialedition/mods/67227
College of Winterhold Quest Start Fixes	https://www.nexusmods.com/skyrimspecialedition/mods/53817
WIDeadBodyCleanupScript Crash Fix	https://www.nexusmods.com/skyrimspecialedition/mods/62413
LOD Unloading Bug Fix	https://www.nexusmods.com/skyrimspecialedition/mods/61251
Quest Journal Limit Bug Fixer - Recover Disappeared Quests	https://www.nexusmods.com/skyrimspecialedition/mods/56130
Allow Dialogue Progress Bugfix	https://www.nexusmods.com/skyrimspecialedition/mods/67433
NPC AI Process Position Fix - NG	https://www.nexusmods.com/skyrimspecialedition/mods/69326